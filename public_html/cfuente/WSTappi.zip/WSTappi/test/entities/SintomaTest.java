/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author alvar
 */
public class SintomaTest {
    
    public SintomaTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getIdsintoma method, of class Sintoma.
     */
    @Test
    public void testGetIdsintoma() {
        System.out.println("getIdsintoma");
        Sintoma instance = new Sintoma();
        Integer expResult = null;
        Integer result = instance.getIdsintoma();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setIdsintoma method, of class Sintoma.
     */
    @Test
    public void testSetIdsintoma() {
        System.out.println("setIdsintoma");
        Integer idsintoma = null;
        Sintoma instance = new Sintoma();
        instance.setIdsintoma(idsintoma);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDescripcionm method, of class Sintoma.
     */
    @Test
    public void testGetDescripcionm() {
        System.out.println("getDescripcionm");
        Sintoma instance = new Sintoma();
        String expResult = "";
        String result = instance.getDescripcionm();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDescripcionm method, of class Sintoma.
     */
    @Test
    public void testSetDescripcionm() {
        System.out.println("setDescripcionm");
        String descripcionm = "";
        Sintoma instance = new Sintoma();
        instance.setDescripcionm(descripcionm);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDescripcionp method, of class Sintoma.
     */
    @Test
    public void testGetDescripcionp() {
        System.out.println("getDescripcionp");
        Sintoma instance = new Sintoma();
        String expResult = "";
        String result = instance.getDescripcionp();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDescripcionp method, of class Sintoma.
     */
    @Test
    public void testSetDescripcionp() {
        System.out.println("setDescripcionp");
        String descripcionp = "";
        Sintoma instance = new Sintoma();
        instance.setDescripcionp(descripcionp);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCoordenadax method, of class Sintoma.
     */
    @Test
    public void testGetCoordenadax() {
        System.out.println("getCoordenadax");
        Sintoma instance = new Sintoma();
        Integer expResult = null;
        Integer result = instance.getCoordenadax();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setCoordenadax method, of class Sintoma.
     */
    @Test
    public void testSetCoordenadax() {
        System.out.println("setCoordenadax");
        Integer coordenadax = null;
        Sintoma instance = new Sintoma();
        instance.setCoordenadax(coordenadax);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCoordenaday method, of class Sintoma.
     */
    @Test
    public void testGetCoordenaday() {
        System.out.println("getCoordenaday");
        Sintoma instance = new Sintoma();
        Integer expResult = null;
        Integer result = instance.getCoordenaday();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setCoordenaday method, of class Sintoma.
     */
    @Test
    public void testSetCoordenaday() {
        System.out.println("setCoordenaday");
        Integer coordenaday = null;
        Sintoma instance = new Sintoma();
        instance.setCoordenaday(coordenaday);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getNivelurgenciaList method, of class Sintoma.
     */
    @Test
    public void testGetNivelurgenciaList() {
        System.out.println("getNivelurgenciaList");
        Sintoma instance = new Sintoma();
        List<Nivelurgencia> expResult = null;
        List<Nivelurgencia> result = instance.getNivelurgenciaList();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setNivelurgenciaList method, of class Sintoma.
     */
    @Test
    public void testSetNivelurgenciaList() {
        System.out.println("setNivelurgenciaList");
        List<Nivelurgencia> nivelurgenciaList = null;
        Sintoma instance = new Sintoma();
        instance.setNivelurgenciaList(nivelurgenciaList);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSintomasxhistoriaList method, of class Sintoma.
     */
    @Test
    public void testGetSintomasxhistoriaList() {
        System.out.println("getSintomasxhistoriaList");
        Sintoma instance = new Sintoma();
        List<Sintomasxhistoria> expResult = null;
        List<Sintomasxhistoria> result = instance.getSintomasxhistoriaList();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setSintomasxhistoriaList method, of class Sintoma.
     */
    @Test
    public void testSetSintomasxhistoriaList() {
        System.out.println("setSintomasxhistoriaList");
        List<Sintomasxhistoria> sintomasxhistoriaList = null;
        Sintoma instance = new Sintoma();
        instance.setSintomasxhistoriaList(sintomasxhistoriaList);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of hashCode method, of class Sintoma.
     */
    @Test
    public void testHashCode() {
        System.out.println("hashCode");
        Sintoma instance = new Sintoma();
        int expResult = 0;
        int result = instance.hashCode();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of equals method, of class Sintoma.
     */
    @Test
    public void testEquals() {
        System.out.println("equals");
        Object object = null;
        Sintoma instance = new Sintoma();
        boolean expResult = false;
        boolean result = instance.equals(object);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class Sintoma.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        Sintoma instance = new Sintoma();
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
