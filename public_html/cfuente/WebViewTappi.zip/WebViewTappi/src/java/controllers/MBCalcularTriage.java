/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import proxyRest.CalcularTriage;
import proxyRest.DTO.Historiaclinica;
import proxyRest.DTO.Sintoma;
import proxyRest.DTO.Sintomasxhistoria;
import proxyRest.DTO.SintomasxhistoriaPK;
import proxyRest.DTO.Usuario;
import proxyRest.HistoriaClinicaRestClient;
import proxyRest.ListadoHistoriasClinicasPorUsuarioRestClient;
import proxyRest.listadoSintomasRestClient;
import proxyRest.loginRestClient;
import proxyRest.ListadoSintomasPorHistoriaRestClient;
import proxyRest.sintomasPorHistoriaRestClient;

/**
 *
 * @author alvar
 */
@Named(value = "mBCalcularTriage")
@SessionScoped
public class MBCalcularTriage implements Serializable{
    
    private String usuario;
    private Usuario theUser ;     
    private Historiaclinica historia;
    private List<Historiaclinica> historias;
    private List<Sintomasxhistoria> sintomasHistoria;
    private List<Sintoma> todosLosSintomas;
    private String idHistoriaClinica;
    private Sintomasxhistoria sintomaHC;
    
    private Historiaclinica nuevaHistoria = new Historiaclinica(new Date());

    public Historiaclinica getNuevaHistoria() {
        return nuevaHistoria;
    }

    public void setNuevaHistoria(Historiaclinica nuevaHistoria) {
        this.nuevaHistoria = nuevaHistoria;
    }
    

    
    
    public Sintomasxhistoria getSintomaHC() {
        return sintomaHC;
    }

    public void setSintomaHC(Sintomasxhistoria sintomaHC) {
        this.sintomaHC = sintomaHC;
    }

    public List<Sintoma> getTodosLosSintomas() {
        if(this.todosLosSintomas == null){
            this.todosLosSintomas = listadoSintomas();
        }
        return todosLosSintomas;
    }

    public void setTodosLosSintomas(List<Sintoma> todosLosSintomas) {
        this.todosLosSintomas = todosLosSintomas;
    }
    
    
    

    public List<Historiaclinica> getHistorias() {
        historias = historiasPorUsuario();
        return historias;
    }

    public void setHistorias(List<Historiaclinica> historias) {
        this.historias = historias;
    }

    public List<Sintomasxhistoria> getSintomasHistoria() {
        this.sintomasHistoria = sintomasPorHistoria();
        return sintomasHistoria;
    }

    public void setSintomasHistoria(List<Sintomasxhistoria> sintomasHistoria) {
        this.sintomasHistoria = sintomasHistoria;
    }

    
    
    
    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }


    public String removeSintomaHC(Sintomasxhistoria sintomaxhistoria) {
        sintomasPorHistoriaRestClient cli = new sintomasPorHistoriaRestClient();
        int historiaclinicaIdhcValue = sintomaxhistoria.getSintomasxhistoriaPK().getHistoriaclinicaIdhc();
        int sintomaIdsintomaValue = sintomaxhistoria.getSintomasxhistoriaPK().getSintomaIdsintoma();
        String path = "/0;historiaclinicaIdhc=" + historiaclinicaIdhcValue + ";sintomaIdsintoma=" + sintomaIdsintomaValue;
        cli.remove(path);        
        return "sintomasHC.xhtml";
    }

    public String formularioListadoHCPorUsuario() {
        return "HCList.xhtml";
    }

    public String formularioNuevaHC(){
       return "addHistoriaClinica.xhtml"; 
    }
    
    
    public String formularioLogin() {
        return "index.xhtml";
    }

    
    public String formularioAddSintomaHC() {
        return "addSintomaHC.xhtml";
    }


    public String addHistoriaClinicaUsuario(){
        HistoriaClinicaRestClient client = new HistoriaClinicaRestClient();
        nuevaHistoria.setUsuarioIdusuario(theUser);
        client.create_XML(this.nuevaHistoria);
        return "HCList.xhtml";        
    }


    
    public String addSintomaHC(Sintoma sintoma) {
        addSintomaForHC(sintoma,"SI");
        return "sintomasHC.xhtml";
    }

    public String addNoSintomaHC(Sintoma sintoma) {
        addSintomaForHC(sintoma,"NO");
        return "sintomasHC.xhtml";
    }



    
    
    private void addSintomaForHC(Sintoma sintoma, String presencia) {
        sintomasPorHistoriaRestClient cli = new sintomasPorHistoriaRestClient();
        Sintomasxhistoria sxh = new Sintomasxhistoria();
        SintomasxhistoriaPK pk = new SintomasxhistoriaPK(this.historia.getIdhistoriaclinica(), sintoma.getIdsintoma());
        sxh.setSintomasxhistoriaPK(pk);
        sxh.setPresencia(presencia);
        sxh.setFecha(new Date());
        sxh.setSintoma(sintoma);
        sxh.setHistoriaclinica(historia);
        cli.create_XML(sxh);
    }

    
    public String selectSintomaHC(Sintomasxhistoria sintomaHistoria) {
        sintomaHC = sintomaHistoria;
        return "verSintomaHC.xhtml";
    }


    
    public String selectHC(Historiaclinica historiaclinica) {
        historia = historiaclinica;
        System.out.println("llega:" + historiaclinica);
        return "sintomasHC.xhtml";
    }
    
    public List<Sintoma> listadoSintomas(){
        listadoSintomasRestClient sintos = new listadoSintomasRestClient();
        return sintos.findAll();
    } 
    public List<Sintomasxhistoria> sintomasPorHistoria(){
        ListadoSintomasPorHistoriaRestClient client = new ListadoSintomasPorHistoriaRestClient();
        return client.findBysintomaxhistoriaclinica(this.historia.getIdhistoriaclinica().toString());
    }
    
    public List<Historiaclinica> historiasPorUsuario(){
        ListadoHistoriasClinicasPorUsuarioRestClient client = new ListadoHistoriasClinicasPorUsuarioRestClient();
        return client.findHCByLogin(this.theUser.getIdusuario().toString());
    }

    public Usuario getTheUser() {
        return theUser;
    }

    public void setTheUser(Usuario theUser) {
        this.theUser = theUser;
    }

    
    
    
    public String autenticarUsuario(){
        if(usuario == null ) return null;
        loginRestClient l = new loginRestClient();
        Usuario user = l.findByLogin_XML(Usuario.class, usuario);        
        if(user!= null){
            this.theUser = user;
            return "HCList.xhtml";
        }
        else{
            return null;
        }
    }
    
    public String calcularTriage(){
       if(this.historia== null) return null;
        CalcularTriage calculo = new CalcularTriage();
        historia = calculo.calculateTriage_XML(Historiaclinica.class, this.historia.getIdhistoriaclinica().toString());        
        return null;
    }

    public Historiaclinica getHistoria() {
        return historia;
    }

    public void setHistoria(Historiaclinica historia) {
        this.historia = historia;
    }

    public String getIdHistoriaClinica() {
        return idHistoriaClinica;
    }

    public void setIdHistoriaClinica(String idHistoriaClinica) {
        this.idHistoriaClinica = idHistoriaClinica;
    }
    
    

    /**
     * Creates a new instance of MBCalcularTriage
     */
    public MBCalcularTriage() {
    }
    
}
