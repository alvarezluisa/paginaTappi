/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proxyRest.DTO;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author alvar
 */
@Entity
@Table(name = "USUARIO", schema="APP")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Usuario.findAll", query = "SELECT u FROM Usuario u"),
    @NamedQuery(name = "Usuario.findByIdusuario", query = "SELECT u FROM Usuario u WHERE u.idusuario = :idusuario"),
    @NamedQuery(name = "Usuario.findByIdfacegoo", query = "SELECT u FROM Usuario u WHERE u.idfacegoo = :idfacegoo"),
    @NamedQuery(name = "Usuario.findByApellido", query = "SELECT u FROM Usuario u WHERE u.apellido = :apellido"),
    @NamedQuery(name = "Usuario.findByCedula", query = "SELECT u FROM Usuario u WHERE u.cedula = :cedula"),
    @NamedQuery(name = "Usuario.findByCorreo", query = "SELECT u FROM Usuario u WHERE u.correo = :correo"),
    @NamedQuery(name = "Usuario.findByDireccion", query = "SELECT u FROM Usuario u WHERE u.direccion = :direccion"),
    @NamedQuery(name = "Usuario.findByFechanacimiento", query = "SELECT u FROM Usuario u WHERE u.fechanacimiento = :fechanacimiento"),
    @NamedQuery(name = "Usuario.findByGenero", query = "SELECT u FROM Usuario u WHERE u.genero = :genero"),
    @NamedQuery(name = "Usuario.findByNombre", query = "SELECT u FROM Usuario u WHERE u.nombre = :nombre"),
    @NamedQuery(name = "Usuario.findByRol", query = "SELECT u FROM Usuario u WHERE u.rol = :rol"),
    @NamedQuery(name = "Usuario.findByTiposangre", query = "SELECT u FROM Usuario u WHERE u.tiposangre = :tiposangre"),
    @NamedQuery(name = "Usuario.findByEps", query = "SELECT u FROM Usuario u WHERE u.eps = :eps"),
    @NamedQuery(name = "Usuario.findByAbortos", query = "SELECT u FROM Usuario u WHERE u.abortos = :abortos"),
    @NamedQuery(name = "Usuario.findByCesareas", query = "SELECT u FROM Usuario u WHERE u.cesareas = :cesareas"),
    @NamedQuery(name = "Usuario.findByFechaprimerperiodo", query = "SELECT u FROM Usuario u WHERE u.fechaprimerperiodo = :fechaprimerperiodo"),
    @NamedQuery(name = "Usuario.findByFechaultimoperiodo", query = "SELECT u FROM Usuario u WHERE u.fechaultimoperiodo = :fechaultimoperiodo"),
    @NamedQuery(name = "Usuario.findByGestas", query = "SELECT u FROM Usuario u WHERE u.gestas = :gestas"),
    @NamedQuery(name = "Usuario.findByMetodoanticonceptivo", query = "SELECT u FROM Usuario u WHERE u.metodoanticonceptivo = :metodoanticonceptivo"),
    @NamedQuery(name = "Usuario.findByPartos", query = "SELECT u FROM Usuario u WHERE u.partos = :partos")})
public class Usuario implements Serializable {

    

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "IDUSUARIO")
    private Integer idusuario;
    @Size(max = 50)
    @Column(name = "IDFACEGOO")
    private String idfacegoo;
    @Size(max = 45)
    @Column(name = "APELLIDO")
    private String apellido;
    @Basic(optional = false)
    @NotNull
    @Column(name = "CEDULA")
    private int cedula;
    @Size(max = 45)
    @Column(name = "CORREO")
    private String correo;
    @Size(max = 45)
    @Column(name = "DIRECCION")
    private String direccion;
    @Column(name = "FECHANACIMIENTO")
    @Temporal(TemporalType.DATE)
    private Date fechanacimiento;
    @Column(name = "GENERO")
    private Character genero;
    @Size(max = 45)
    @Column(name = "NOMBRE")
    private String nombre;
    @Size(max = 50)
    @Column(name = "ROL")
    private String rol;
    @Size(max = 3)
    @Column(name = "TIPOSANGRE")
    private String tiposangre;
    @Size(max = 45)
    @Column(name = "EPS")
    private String eps;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ABORTOS")
    private int abortos;
    @Basic(optional = false)
    @NotNull
    @Column(name = "CESAREAS")
    private int cesareas;
    @Column(name = "FECHAPRIMERPERIODO")
    @Temporal(TemporalType.DATE)
    private Date fechaprimerperiodo;
    @Column(name = "FECHAULTIMOPERIODO")
    @Temporal(TemporalType.DATE)
    private Date fechaultimoperiodo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "GESTAS")
    private int gestas;
    @Size(max = 45)
    @Column(name = "METODOANTICONCEPTIVO")
    private String metodoanticonceptivo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "PARTOS")
    private int partos;
    

    @XmlTransient
    private String rolTexto;

    public String getRolTexto() {
        if(this.rol.equals("M")){
            this.rolTexto = "MEDICO";
        }
        else{
            this.rolTexto = "PACIENTE";
        }
        return rolTexto;
    }

    public void setRolTexto(String rolTexto) {
        this.rolTexto = rolTexto;
    }
    
    
    
    
    public Usuario() {
    }

    public Usuario(Integer idusuario) {
        this.idusuario = idusuario;
    }

    public Usuario(Integer idusuario, int cedula, int abortos, int cesareas, int gestas, int partos) {
        this.idusuario = idusuario;
        this.cedula = cedula;
        this.abortos = abortos;
        this.cesareas = cesareas;
        this.gestas = gestas;
        this.partos = partos;
    }

    public Integer getIdusuario() {
        return idusuario;
    }

    public void setIdusuario(Integer idusuario) {
        this.idusuario = idusuario;
    }

    public String getIdfacegoo() {
        return idfacegoo;
    }

    public void setIdfacegoo(String idfacegoo) {
        this.idfacegoo = idfacegoo;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getCedula() {
        return cedula;
    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public Date getFechanacimiento() {
        return fechanacimiento;
    }

    public void setFechanacimiento(Date fechanacimiento) {
        this.fechanacimiento = fechanacimiento;
    }

    public Character getGenero() {
        return genero;
    }

    public void setGenero(Character genero) {
        this.genero = genero;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public String getTiposangre() {
        return tiposangre;
    }

    public void setTiposangre(String tiposangre) {
        this.tiposangre = tiposangre;
    }

    public String getEps() {
        return eps;
    }

    public void setEps(String eps) {
        this.eps = eps;
    }

    public int getAbortos() {
        return abortos;
    }

    public void setAbortos(int abortos) {
        this.abortos = abortos;
    }

    public int getCesareas() {
        return cesareas;
    }

    public void setCesareas(int cesareas) {
        this.cesareas = cesareas;
    }

    public Date getFechaprimerperiodo() {
        return fechaprimerperiodo;
    }

    public void setFechaprimerperiodo(Date fechaprimerperiodo) {
        this.fechaprimerperiodo = fechaprimerperiodo;
    }

    public Date getFechaultimoperiodo() {
        return fechaultimoperiodo;
    }

    public void setFechaultimoperiodo(Date fechaultimoperiodo) {
        this.fechaultimoperiodo = fechaultimoperiodo;
    }

    public int getGestas() {
        return gestas;
    }

    public void setGestas(int gestas) {
        this.gestas = gestas;
    }

    public String getMetodoanticonceptivo() {
        return metodoanticonceptivo;
    }

    public void setMetodoanticonceptivo(String metodoanticonceptivo) {
        this.metodoanticonceptivo = metodoanticonceptivo;
    }

    public int getPartos() {
        return partos;
    }

    public void setPartos(int partos) {
        this.partos = partos;
    }

    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idusuario != null ? idusuario.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Usuario)) {
            return false;
        }
        Usuario other = (Usuario) object;
        if ((this.idusuario == null && other.idusuario != null) || (this.idusuario != null && !this.idusuario.equals(other.idusuario))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Usuario[ idusuario=" + idusuario + " ]";
    }

    
    
}
