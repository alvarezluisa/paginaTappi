/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entities.Antecedente;
import entities.Usuarioxantecedente;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import proxyRest.ListadoAntecedentePorUsuarioRestClient;

/**
 *
 * @author alvar
 */
public class ListarantecedentexusuarioFacadeRESTTest {
    
    public ListarantecedentexusuarioFacadeRESTTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of findByantedentesbyusuario method, of class ListarantecedentexusuarioFacadeREST.
     */
    @Test
    public void testFindByantedentesbyusuario() {
        System.out.println("findByantedentesbyusuario");
        Integer idU = 1;
        ListadoAntecedentePorUsuarioRestClient  instance = new ListadoAntecedentePorUsuarioRestClient();
        Integer expResult []= {1,2,5,15} ;
        List<Usuarioxantecedente> listUsAn = instance.findAnByidU(idU);
        Integer result []= new Integer [4];
        int i=0;
        for(Usuarioxantecedente l : listUsAn)
        {
            result[i]=l.getAntecedente().getIdantecedente();
            i++;
        }
            
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of putXml method, of class ListarantecedentexusuarioFacadeREST.
     */
//    @Test
//    public void testPutXml() {
//        System.out.println("putXml");
//        Antecedente content = null;
//        ListarantecedentexusuarioFacadeREST instance = new ListarantecedentexusuarioFacadeREST();
//        instance.putXml(content);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
    
}
