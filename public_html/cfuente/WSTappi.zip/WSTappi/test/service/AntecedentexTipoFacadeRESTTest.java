/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entities.Antecedente;
import java.util.List;
import javax.ejb.embeddable.EJBContainer;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import proxyRest.tipoAntecedenteRestClient;

/**
 *
 * @author alvar
 */
public class AntecedentexTipoFacadeRESTTest {

    public AntecedentexTipoFacadeRESTTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of putXml method, of class AntecedentexTipoFacadeREST.
     */
//    @Test
//    public void testPutXml() throws Exception {
//        System.out.println("putXml");
//        String content = "";
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        AntecedentexTipoFacadeREST instance = (AntecedentexTipoFacadeREST)container.getContext().lookup("java:global/classes/AntecedentexTipoFacadeREST");
//        instance.putXml(content);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
    /**
     * Test of findByType method, of class AntecedentexTipoFacadeREST.
     */
    @Test
    public void testFindByType() throws Exception {
        System.out.println("findByType");
        String t = "INMUNIZACION";
        AntecedentexTipoFacadeREST instance = new AntecedentexTipoFacadeREST();
        Integer expResult = 1;
        tipoAntecedenteRestClient l = new tipoAntecedenteRestClient();
        List<Antecedente> result= l.findByType_List(t);

        assertEquals(expResult, new Integer (result.size()));
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

}
