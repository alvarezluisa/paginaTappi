/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author alvar
 */
@Entity
@Table(name = "USUARIOXANTECEDENTE", schema="APP")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Usuarioxantecedente.findAll", query = "SELECT u FROM Usuarioxantecedente u"),
    @NamedQuery(name = "Usuarioxantecedente.findByUsuarioIdusuario", query = "SELECT u FROM Usuarioxantecedente u WHERE u.usuarioxantecedentePK.usuarioIdusuario = :usuarioIdusuario"),
    @NamedQuery(name = "Usuarioxantecedente.findByAntecedenteIdantecedente", query = "SELECT u FROM Usuarioxantecedente u WHERE u.usuarioxantecedentePK.antecedenteIdantecedente = :antecedenteIdantecedente"),
    @NamedQuery(name = "Usuarioxantecedente.findByAux", query = "SELECT u FROM Usuarioxantecedente u WHERE u.aux = :aux")})
public class Usuarioxantecedente implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected UsuarioxantecedentePK usuarioxantecedentePK;
    @Column(name = "AUX")
    private Boolean aux;
    @JoinColumn(name = "ANTECEDENTE_IDANTECEDENTE", referencedColumnName = "IDANTECEDENTE", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Antecedente antecedente;
    @JoinColumn(name = "USUARIO_IDUSUARIO", referencedColumnName = "IDUSUARIO", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Usuario usuario;

    public Usuarioxantecedente() {
    }

    public Usuarioxantecedente(UsuarioxantecedentePK usuarioxantecedentePK) {
        this.usuarioxantecedentePK = usuarioxantecedentePK;
    }

    public Usuarioxantecedente(int usuarioIdusuario, int antecedenteIdantecedente) {
        this.usuarioxantecedentePK = new UsuarioxantecedentePK(usuarioIdusuario, antecedenteIdantecedente);
    }

    public UsuarioxantecedentePK getUsuarioxantecedentePK() {
        return usuarioxantecedentePK;
    }

    public void setUsuarioxantecedentePK(UsuarioxantecedentePK usuarioxantecedentePK) {
        this.usuarioxantecedentePK = usuarioxantecedentePK;
    }

    public Boolean getAux() {
        return aux;
    }

    public void setAux(Boolean aux) {
        this.aux = aux;
    }

    public Antecedente getAntecedente() {
        return antecedente;
    }

    public void setAntecedente(Antecedente antecedente) {
        this.antecedente = antecedente;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (usuarioxantecedentePK != null ? usuarioxantecedentePK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Usuarioxantecedente)) {
            return false;
        }
        Usuarioxantecedente other = (Usuarioxantecedente) object;
        if ((this.usuarioxantecedentePK == null && other.usuarioxantecedentePK != null) || (this.usuarioxantecedentePK != null && !this.usuarioxantecedentePK.equals(other.usuarioxantecedentePK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Usuarioxantecedente[ usuarioxantecedentePK=" + usuarioxantecedentePK + " ]";
    }
    
}
