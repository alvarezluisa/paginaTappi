/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entities.Historiaclinica;
import entities.Usuario;
import java.sql.Date;
import javax.ejb.embeddable.EJBContainer;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author alvar
 */
public class HistoriaclinicaFacadeRESTTest {
    
    public HistoriaclinicaFacadeRESTTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of edit method, of class HistoriaclinicaFacadeREST.
     */
    @Test
    public void testEdit_GenericType() throws Exception {
        System.out.println("edit");
        Historiaclinica entity = null;
        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
        HistoriaclinicaFacadeREST instance = 
                (HistoriaclinicaFacadeREST)
                container.getContext().lookup("java:global/classes/HistoriaclinicaFacadeREST");
        entity = instance.find(7);
        entity.setDescripcionmotivourgencia("DOLOR PECTORAL FUERTE");
        instance.edit(entity);
        assertEquals("DOLOR PECTORAL FUERTE", instance.find(7).getDescripcionmotivourgencia());
        container.close();
        
        // TODO review the generated test code and remove the default call to fail.
        // fail("The test case is a prototype.");
    }

    /**
     * Test of remove method, of class HistoriaclinicaFacadeREST.
     */
//    @Test
//    public void testRemove_GenericType() throws Exception {
//        System.out.println("remove");
//        Historiaclinica entity = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        HistoriaclinicaFacadeREST instance = (HistoriaclinicaFacadeREST)container.getContext().lookup("java:global/classes/HistoriaclinicaFacadeREST");
//        instance.remove(entity);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }

    /**
     * Test of find method, of class HistoriaclinicaFacadeREST.
     */
//    @Test
//    public void testFind_Object() throws Exception {
//        System.out.println("find");
//        Object id = 1;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        HistoriaclinicaFacadeREST instance = 
//                (HistoriaclinicaFacadeREST)
//                container.getContext().lookup("java:global/classes/HistoriaclinicaFacadeREST");
//        Integer expResult = 1;
//        Historiaclinica result = instance.find(id);
//        assertEquals(expResult, result.getIdhistoriaclinica());
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        //fail("The test case is a prototype.");
//    }

    /**
     * Test of findRange method, of class HistoriaclinicaFacadeREST.
     */
//    @Test
//    public void testFindRange_intArr() throws Exception {
//        System.out.println("findRange");
//        int[] range = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        HistoriaclinicaFacadeREST instance = (HistoriaclinicaFacadeREST)container.getContext().lookup("java:global/classes/HistoriaclinicaFacadeREST");
//        List<Historiaclinica> expResult = null;
//        List<Historiaclinica> result = instance.findRange(range);
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }

    /**
     * Test of count method, of class HistoriaclinicaFacadeREST.
     */
//    @Test
//    public void testCount() throws Exception {
//        System.out.println("count");
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        HistoriaclinicaFacadeREST instance = (HistoriaclinicaFacadeREST)container.getContext().lookup("java:global/classes/HistoriaclinicaFacadeREST");
//        int expResult = 0;
//        int result = instance.count();
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }

    /**
     * Test of create method, of class HistoriaclinicaFacadeREST.
     * Se debe probar el método de POST para la clase Historia Clinica
     */
//    @Test
//    public void testCreate() throws Exception {
//        System.out.println("create");
//        Historiaclinica entity = new Historiaclinica();
//        entity.setIdhistoriaclinica(7);
//        entity.setDescripcionmotivourgencia("DOLOR NARIZ");
//        entity.setFecha(new Date(2016,10,12));
//        entity.setIniciomotivourgencia(new Date(2016,10,12));
//        Usuario u = null;
//     
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        UsuarioFacadeREST instance1 = 
//                (UsuarioFacadeREST)container.getContext().lookup("java:global/classes/UsuarioFacadeREST");
//        u = instance1.find(2);
//        entity.setUsuarioIdusuario(u);
//        HistoriaclinicaFacadeREST instance = 
//                (HistoriaclinicaFacadeREST)container.getContext().lookup("java:global/classes/HistoriaclinicaFacadeREST");
//        instance.create(entity);
//        assertEquals(new Integer (7), entity.getIdhistoriaclinica());
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        //fail("The test case is a prototype.");
//    }

    /**
     * Test of edit method, of class HistoriaclinicaFacadeREST.
     */
//    @Test
//    public void testEdit_Integer_Historiaclinica() throws Exception {
//        System.out.println("edit");
//        Integer id = null;
//        Historiaclinica entity = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        HistoriaclinicaFacadeREST instance = (HistoriaclinicaFacadeREST)container.getContext().lookup("java:global/classes/HistoriaclinicaFacadeREST");
//        instance.edit(id, entity);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of remove method, of class HistoriaclinicaFacadeREST.
//     */
//    @Test
//    public void testRemove_Integer() throws Exception {
//        System.out.println("remove");
//        Integer id = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        HistoriaclinicaFacadeREST instance = (HistoriaclinicaFacadeREST)container.getContext().lookup("java:global/classes/HistoriaclinicaFacadeREST");
//        instance.remove(id);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of find method, of class HistoriaclinicaFacadeREST.
//     */
//    @Test
//    public void testFind_Integer() throws Exception {
//        System.out.println("find");
//        Integer id = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        HistoriaclinicaFacadeREST instance = (HistoriaclinicaFacadeREST)container.getContext().lookup("java:global/classes/HistoriaclinicaFacadeREST");
//        Historiaclinica expResult = null;
//        Historiaclinica result = instance.find(id);
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of findAll method, of class HistoriaclinicaFacadeREST.
//     */
//    @Test
//    public void testFindAll() throws Exception {
//        System.out.println("findAll");
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        HistoriaclinicaFacadeREST instance = (HistoriaclinicaFacadeREST)container.getContext().lookup("java:global/classes/HistoriaclinicaFacadeREST");
//        List<Historiaclinica> expResult = null;
//        List<Historiaclinica> result = instance.findAll();
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of findRange method, of class HistoriaclinicaFacadeREST.
//     */
//    @Test
//    public void testFindRange_Integer_Integer() throws Exception {
//        System.out.println("findRange");
//        Integer from = null;
//        Integer to = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        HistoriaclinicaFacadeREST instance = (HistoriaclinicaFacadeREST)container.getContext().lookup("java:global/classes/HistoriaclinicaFacadeREST");
//        List<Historiaclinica> expResult = null;
//        List<Historiaclinica> result = instance.findRange(from, to);
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of countREST method, of class HistoriaclinicaFacadeREST.
//     */
//    @Test
//    public void testCountREST() throws Exception {
//        System.out.println("countREST");
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        HistoriaclinicaFacadeREST instance = (HistoriaclinicaFacadeREST)container.getContext().lookup("java:global/classes/HistoriaclinicaFacadeREST");
//        String expResult = "";
//        String result = instance.countREST();
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
    
}
