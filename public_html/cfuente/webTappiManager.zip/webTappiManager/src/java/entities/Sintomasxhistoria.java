/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author alvar
 */
@Entity
@Table(name = "SINTOMASXHISTORIA", schema="APP")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Sintomasxhistoria.findAll", query = "SELECT s FROM Sintomasxhistoria s"),
    @NamedQuery(name = "Sintomasxhistoria.findByFecha", query = "SELECT s FROM Sintomasxhistoria s WHERE s.fecha = :fecha"),
    @NamedQuery(name = "Sintomasxhistoria.findByHistoriaclinicaIdhc", query = "SELECT s FROM Sintomasxhistoria s WHERE s.sintomasxhistoriaPK.historiaclinicaIdhc = :historiaclinicaIdhc"),
    @NamedQuery(name = "Sintomasxhistoria.findBySintomaIdsintoma", query = "SELECT s FROM Sintomasxhistoria s WHERE s.sintomasxhistoriaPK.sintomaIdsintoma = :sintomaIdsintoma"),
    @NamedQuery(name = "Sintomasxhistoria.findByPresencia", query = "SELECT s FROM Sintomasxhistoria s WHERE s.presencia = :presencia")})
public class Sintomasxhistoria implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected SintomasxhistoriaPK sintomasxhistoriaPK;
    @Column(name = "FECHA")
    @Temporal(TemporalType.DATE)
    private Date fecha;
    @Size(max = 2)
    @Column(name = "PRESENCIA")
    private String presencia;
    @JoinColumn(name = "HISTORIACLINICA_IDHC", referencedColumnName = "IDHISTORIACLINICA", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Historiaclinica historiaclinica;
    @JoinColumn(name = "SINTOMA_IDSINTOMA", referencedColumnName = "IDSINTOMA", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Sintoma sintoma;

    public Sintomasxhistoria() {
    }

    public Sintomasxhistoria(SintomasxhistoriaPK sintomasxhistoriaPK) {
        this.sintomasxhistoriaPK = sintomasxhistoriaPK;
    }

    public Sintomasxhistoria(int historiaclinicaIdhc, int sintomaIdsintoma) {
        this.sintomasxhistoriaPK = new SintomasxhistoriaPK(historiaclinicaIdhc, sintomaIdsintoma);
    }

    public SintomasxhistoriaPK getSintomasxhistoriaPK() {
        return sintomasxhistoriaPK;
    }

    public void setSintomasxhistoriaPK(SintomasxhistoriaPK sintomasxhistoriaPK) {
        this.sintomasxhistoriaPK = sintomasxhistoriaPK;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getPresencia() {
        return presencia;
    }

    public void setPresencia(String presencia) {
        this.presencia = presencia;
    }

    public Historiaclinica getHistoriaclinica() {
        return historiaclinica;
    }

    public void setHistoriaclinica(Historiaclinica historiaclinica) {
        this.historiaclinica = historiaclinica;
    }

    public Sintoma getSintoma() {
        return sintoma;
    }

    public void setSintoma(Sintoma sintoma) {
        this.sintoma = sintoma;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (sintomasxhistoriaPK != null ? sintomasxhistoriaPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Sintomasxhistoria)) {
            return false;
        }
        Sintomasxhistoria other = (Sintomasxhistoria) object;
        if ((this.sintomasxhistoriaPK == null && other.sintomasxhistoriaPK != null) || (this.sintomasxhistoriaPK != null && !this.sintomasxhistoriaPK.equals(other.sintomasxhistoriaPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Sintomasxhistoria[ sintomasxhistoriaPK=" + sintomasxhistoriaPK + " ]";
    }
    
}
