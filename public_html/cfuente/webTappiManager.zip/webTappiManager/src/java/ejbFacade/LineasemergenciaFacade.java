/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejbFacade;

import entities.Lineasemergencia;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author alvar
 */
@Stateless
public class LineasemergenciaFacade extends AbstractFacade<Lineasemergencia> {

    @PersistenceContext(unitName = "webTappiManagerPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public LineasemergenciaFacade() {
        super(Lineasemergencia.class);
    }
    
}
