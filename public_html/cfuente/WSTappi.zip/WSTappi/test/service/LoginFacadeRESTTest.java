/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entities.Usuario;
import javax.ejb.embeddable.EJBContainer;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import proxyRest.loginRestClient;

/**
 *
 * @author alvar
 */
public class LoginFacadeRESTTest {
    
//    private EJBContainer ejbContainer;
//    private Context  ctx;


    
    public LoginFacadeRESTTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
//         ejbContainer = EJBContainer.createEJBContainer();
//        System.out.println("Opening the container" );
//        ctx = ejbContainer.getContext();
        

    }
    
    @After
    public void tearDown() {
//        ejbContainer.close();
//        System.out.println("Closing the container" );

    }

    /**
     * Test of findByLogin method, of class LoginFacadeREST.
     * Prueba 1: Se debe probar que dado un id de Facebook o Google + el sistema retorne 
     * el id de usuario para identificar dicho usuario en la aplicación.
     */
    @Test
    public void testFindByLogin() throws NamingException {
        
        
        System.out.println("findByLogin");
        String fg = "165465";
        loginRestClient l = new loginRestClient();
        Integer expResult = new Integer("1");
        Usuario result = l.findByLogin_XML(Usuario.class, fg);
        assertEquals(expResult, result.getIdusuario());
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
    
    
    

   
    
}
