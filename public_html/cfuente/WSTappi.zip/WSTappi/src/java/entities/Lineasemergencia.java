/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author alvar
 */
@Entity
@Table(name = "LINEASEMERGENCIA", schema="APP")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Lineasemergencia.findAll", query = "SELECT l FROM Lineasemergencia l"),
    @NamedQuery(name = "Lineasemergencia.findByIdlineasemergencia", query = "SELECT l FROM Lineasemergencia l WHERE l.idlineasemergencia = :idlineasemergencia"),
    @NamedQuery(name = "Lineasemergencia.findByNumero", query = "SELECT l FROM Lineasemergencia l WHERE l.numero = :numero"),
    @NamedQuery(name = "Lineasemergencia.findByDescripcion", query = "SELECT l FROM Lineasemergencia l WHERE l.descripcion = :descripcion")})
public class Lineasemergencia implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "IDLINEASEMERGENCIA")
    private Integer idlineasemergencia;
    @Column(name = "NUMERO")
    private Integer numero;
    @Size(max = 50)
    @Column(name = "DESCRIPCION")
    private String descripcion;

    public Lineasemergencia() {
    }

    public Lineasemergencia(Integer idlineasemergencia) {
        this.idlineasemergencia = idlineasemergencia;
    }

    public Integer getIdlineasemergencia() {
        return idlineasemergencia;
    }

    public void setIdlineasemergencia(Integer idlineasemergencia) {
        this.idlineasemergencia = idlineasemergencia;
    }

    public Integer getNumero() {
        return numero;
    }

    public void setNumero(Integer numero) {
        this.numero = numero;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idlineasemergencia != null ? idlineasemergencia.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Lineasemergencia)) {
            return false;
        }
        Lineasemergencia other = (Lineasemergencia) object;
        if ((this.idlineasemergencia == null && other.idlineasemergencia != null) || (this.idlineasemergencia != null && !this.idlineasemergencia.equals(other.idlineasemergencia))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Lineasemergencia[ idlineasemergencia=" + idlineasemergencia + " ]";
    }
    
}
