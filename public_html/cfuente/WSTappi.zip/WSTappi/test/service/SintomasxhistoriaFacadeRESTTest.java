/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entities.Historiaclinica;
import entities.Sintoma;
import entities.Sintomasxhistoria;
import entities.SintomasxhistoriaPK;
import java.sql.Date;
import java.util.List;
import javax.ejb.embeddable.EJBContainer;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author alvar
 */
public class SintomasxhistoriaFacadeRESTTest {

    public SintomasxhistoriaFacadeRESTTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of edit method, of class SintomasxhistoriaFacadeREST.
     */
//    @Test
//    public void testEdit_GenericType() throws Exception {
//        System.out.println("edit");
//        Sintomasxhistoria entity = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        SintomasxhistoriaFacadeREST instance = 
//                (SintomasxhistoriaFacadeREST)
//                container.getContext().lookup("java:global/classes/SintomasxhistoriaFacadeREST");
//        for(Sintomasxhistoria sh: instance.findAll())
//            if(sh.getHistoriaclinica().getIdhistoriaclinica()== 7 && sh.getSintoma().getIdsintoma()== 1)
//                entity =sh;
//        entity.setPresencia("NO");
//        instance.edit(entity);
//        container.close();
//        
//        assertEquals(new String ("NO"), entity.getPresencia());
//        // TODO review the generated test code and remove the default call to fail.
//        //fail("The test case is a prototype.");
//    }
//    /**
//     * Test of remove method, of class SintomasxhistoriaFacadeREST.
//     */
    @Test
    public void testRemove_GenericType() throws Exception {
        System.out.println("remove");
        Sintomasxhistoria entity;
        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
        SintomasxhistoriaFacadeREST instance = 
                (SintomasxhistoriaFacadeREST)
                container.getContext().lookup("java:global/classes/SintomasxhistoriaFacadeREST");
        entity = instance.find(new SintomasxhistoriaPK(7,1));
        instance.remove(entity);
        container.close();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    /**
     * Test of find method, of class SintomasxhistoriaFacadeREST.
     */
//    @Test
//    public void testFind_Object() throws Exception {
//        System.out.println("find");
//        Object id = 1;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        SintomasxhistoriaFacadeREST instance = 
//                (SintomasxhistoriaFacadeREST)
//                container.getContext().lookup("java:global/classes/SintomasxhistoriaFacadeREST");
//        Integer expResult []= {1,2,3,4};
//        List <Sintomasxhistoria> result = instance.findAll();
//        Integer [] idSin= new Integer [4];
//        int i=0;
//        for(Sintomasxhistoria s:result)
//        {
//            if(s.getHistoriaclinica().getIdhistoriaclinica()==1)
//            {
//                
//                idSin[i]=s.getSintoma().getIdsintoma();
//                i++;
//            }
//        }
//            
//        //System.out.println(result.toString());
//        assertEquals(expResult, idSin);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        //fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of findRange method, of class SintomasxhistoriaFacadeREST.
//     */
//    @Test
//    public void testFindRange_intArr() throws Exception {
//        System.out.println("findRange");
//        int[] range = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        SintomasxhistoriaFacadeREST instance = (SintomasxhistoriaFacadeREST)container.getContext().lookup("java:global/classes/SintomasxhistoriaFacadeREST");
//        List<Sintomasxhistoria> expResult = null;
//        List<Sintomasxhistoria> result = instance.findRange(range);
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of count method, of class SintomasxhistoriaFacadeREST.
//     */
//    @Test
//    public void testCount() throws Exception {
//        System.out.println("count");
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        SintomasxhistoriaFacadeREST instance = (SintomasxhistoriaFacadeREST)container.getContext().lookup("java:global/classes/SintomasxhistoriaFacadeREST");
//        int expResult = 0;
//        int result = instance.count();
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
    /**
     * Test of create method, of class SintomasxhistoriaFacadeREST.
     */
//    @Test
//    public void testCreate() throws Exception {
//        System.out.println("create");
//        Sintomasxhistoria entity;
//        entity = new Sintomasxhistoria();
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        HistoriaclinicaFacadeREST instance1 = 
//                (HistoriaclinicaFacadeREST ) 
//                container.getContext().lookup("java:global/classes/HistoriaclinicaFacadeREST");
//        Historiaclinica h = null;
//        h = instance1.find(7);
//        entity.setHistoriaclinica(h);
//        entity.setFecha(new Date(2016,10,11));
//        entity.setPresencia("SI");
//
//        Sintoma s =null;
//        SintomaFacadeREST instance2 = 
//                (SintomaFacadeREST ) 
//                container.getContext().lookup("java:global/classes/SintomaFacadeREST");
//        s = instance2.find(4);
//        entity.setSintoma(s);
//        SintomasxhistoriaPK sh;
//        sh = new SintomasxhistoriaPK();
//        sh.setHistoriaclinicaIdhc(7);
//        sh.setSintomaIdsintoma(4);
//        
//        entity.setSintomasxhistoriaPK(sh);
//        SintomasxhistoriaFacadeREST instance = 
//                (SintomasxhistoriaFacadeREST) 
//                container.getContext().lookup("java:global/classes/SintomasxhistoriaFacadeREST");
//        instance.create(entity);
//        container.close();
//        assertEquals(new Integer(4), entity.getSintoma().getIdsintoma());
//        // TODO review the generated test code and remove the default call to fail.
//        //fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of edit method, of class SintomasxhistoriaFacadeREST.
//     */
//    @Test
//    public void testEdit_PathSegment_Sintomasxhistoria() throws Exception {
//        System.out.println("edit");
//        PathSegment id = null;
//        Sintomasxhistoria entity = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        SintomasxhistoriaFacadeREST instance = (SintomasxhistoriaFacadeREST)container.getContext().lookup("java:global/classes/SintomasxhistoriaFacadeREST");
//        instance.edit(id, entity);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of remove method, of class SintomasxhistoriaFacadeREST.
//     */
//    @Test
//    public void testRemove_PathSegment() throws Exception {
//        System.out.println("remove");
//        PathSegment id = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        SintomasxhistoriaFacadeREST instance = (SintomasxhistoriaFacadeREST)container.getContext().lookup("java:global/classes/SintomasxhistoriaFacadeREST");
//        instance.remove(id);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of find method, of class SintomasxhistoriaFacadeREST.
//     */
//    @Test
//    public void testFind_PathSegment() throws Exception {
//        System.out.println("find");
//        PathSegment id = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        SintomasxhistoriaFacadeREST instance = (SintomasxhistoriaFacadeREST)container.getContext().lookup("java:global/classes/SintomasxhistoriaFacadeREST");
//        Sintomasxhistoria expResult = null;
//        Sintomasxhistoria result = instance.find(id);
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of findAll method, of class SintomasxhistoriaFacadeREST.
//     */
//    @Test
//    public void testFindAll() throws Exception {
//        System.out.println("findAll");
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        SintomasxhistoriaFacadeREST instance = (SintomasxhistoriaFacadeREST)container.getContext().lookup("java:global/classes/SintomasxhistoriaFacadeREST");
//        List<Sintomasxhistoria> expResult = null;
//        List<Sintomasxhistoria> result = instance.findAll();
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of findRange method, of class SintomasxhistoriaFacadeREST.
//     */
//    @Test
//    public void testFindRange_Integer_Integer() throws Exception {
//        System.out.println("findRange");
//        Integer from = null;
//        Integer to = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        SintomasxhistoriaFacadeREST instance = (SintomasxhistoriaFacadeREST)container.getContext().lookup("java:global/classes/SintomasxhistoriaFacadeREST");
//        List<Sintomasxhistoria> expResult = null;
//        List<Sintomasxhistoria> result = instance.findRange(from, to);
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of countREST method, of class SintomasxhistoriaFacadeREST.
//     */
//    @Test
//    public void testCountREST() throws Exception {
//        System.out.println("countREST");
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        SintomasxhistoriaFacadeREST instance = (SintomasxhistoriaFacadeREST)container.getContext().lookup("java:global/classes/SintomasxhistoriaFacadeREST");
//        String expResult = "";
//        String result = instance.countREST();
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }

}
