/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entities.Antecedente;
import entities.Usuario;
import entities.Usuarioxantecedente;
import entities.UsuarioxantecedentePK;
import javax.ejb.embeddable.EJBContainer;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import static org.junit.Assert.*;
import org.junit.Test;

/**
 *
 * @author alvar
 */
public class UsuarioxantecedenteFacadeRESTTest {
    
    public UsuarioxantecedenteFacadeRESTTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of edit method, of class UsuarioxantecedenteFacadeREST.
     */
    @Test
    public void testEdit_GenericType() throws Exception {
        System.out.println("edit");
        UsuarioxantecedentePK id = new UsuarioxantecedentePK(1,1);
        Usuarioxantecedente entity = null;
        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
        UsuarioxantecedenteFacadeREST instance = 
                (UsuarioxantecedenteFacadeREST)
                container.getContext().lookup("java:global/classes/UsuarioxantecedenteFacadeREST");
        entity = instance.find(id);
        entity.setAux(true);
        instance.edit(entity);
        assertEquals(true, instance.find(id).getAux());
        container.close();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
//
//    /**
//     * Test of remove method, of class UsuarioxantecedenteFacadeREST.
//     */
//    @Test
//    public void testRemove_GenericType() throws Exception {
//        System.out.println("remove");
//        Usuarioxantecedente entity = null;
//        Integer idUsuario =1;
//        Integer idAntece =15;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        UsuarioxantecedenteFacadeREST instance = 
//                (UsuarioxantecedenteFacadeREST)
//                container.getContext().lookup("java:global/classes/UsuarioxantecedenteFacadeREST");
//        entity = instance.find(new UsuarioxantecedentePK(idUsuario, idAntece));
//        //System.out.println(entity.toString());
//        instance.remove(entity);
//        Usuario find = null;
//        try{
//            instance.find(new UsuarioxantecedentePK(idUsuario, idAntece));
//        }catch(Exception ex){
//            //
//        }
//        assertNull(find);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        //fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of find method, of class UsuarioxantecedenteFacadeREST.
//     */
//    @Test
//    public void testFind_Object() throws Exception {
//        System.out.println("find");
//        Object id = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        UsuarioxantecedenteFacadeREST instance = (UsuarioxantecedenteFacadeREST)container.getContext().lookup("java:global/classes/UsuarioxantecedenteFacadeREST");
//        Usuarioxantecedente expResult = null;
//        Usuarioxantecedente result = instance.find(id);
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of findRange method, of class UsuarioxantecedenteFacadeREST.
//     */
//    @Test
//    public void testFindRange_intArr() throws Exception {
//        System.out.println("findRange");
//        int[] range = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        UsuarioxantecedenteFacadeREST instance = (UsuarioxantecedenteFacadeREST)container.getContext().lookup("java:global/classes/UsuarioxantecedenteFacadeREST");
//        List<Usuarioxantecedente> expResult = null;
//        List<Usuarioxantecedente> result = instance.findRange(range);
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of count method, of class UsuarioxantecedenteFacadeREST.
//     */
//    @Test
//    public void testCount() throws Exception {
//        System.out.println("count");
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        UsuarioxantecedenteFacadeREST instance = (UsuarioxantecedenteFacadeREST)container.getContext().lookup("java:global/classes/UsuarioxantecedenteFacadeREST");
//        int expResult = 0;
//        int result = instance.count();
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of create method, of class UsuarioxantecedenteFacadeREST.
//     */
//   @Test
//    public void testCreate() throws Exception {
//        System.out.println("create");
//        Usuarioxantecedente entity = new Usuarioxantecedente(1,15);
//        
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        UsuarioFacadeREST instance2 = 
//                (UsuarioFacadeREST)
//                container.getContext().lookup("java:global/classes/UsuarioFacadeREST");
//        entity.setUsuario(instance2.find(1));
//        AntecedenteFacadeREST instance1 = 
//                (AntecedenteFacadeREST)
//                container.getContext().lookup("java:global/classes/AntecedenteFacadeREST");
//        entity.setAntecedente(instance1.find(15));
//        UsuarioxantecedenteFacadeREST instance = 
//                (UsuarioxantecedenteFacadeREST)
//                container.getContext().lookup("java:global/classes/UsuarioxantecedenteFacadeREST");
//        instance.create(entity);
//        container.close();
//        assertEquals(15, entity.getUsuarioxantecedentePK().getAntecedenteIdantecedente());        
//        // TODO review the generated test code and remove the default call to fail.
//        //fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of edit method, of class UsuarioxantecedenteFacadeREST.
//     */
//    @Test
//    public void testEdit_PathSegment_Usuarioxantecedente() throws Exception {
//        System.out.println("edit");
//        PathSegment id = null;
//        Usuarioxantecedente entity = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        UsuarioxantecedenteFacadeREST instance = 
//                (UsuarioxantecedenteFacadeREST)
//                container.getContext().lookup("java:global/classes/UsuarioxantecedenteFacadeREST");
//        instance.edit(id, entity);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of remove method, of class UsuarioxantecedenteFacadeREST.
//     */
//    @Test
//    public void testRemove_PathSegment() throws Exception {
//        System.out.println("remove");
//        PathSegment id = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        UsuarioxantecedenteFacadeREST instance = (UsuarioxantecedenteFacadeREST)container.getContext().lookup("java:global/classes/UsuarioxantecedenteFacadeREST");
//        instance.remove(id);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of find method, of class UsuarioxantecedenteFacadeREST.
//     */
//    @Test
//    public void testFind_PathSegment() throws Exception {
//        System.out.println("find");
//        PathSegment id = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        UsuarioxantecedenteFacadeREST instance = (UsuarioxantecedenteFacadeREST)container.getContext().lookup("java:global/classes/UsuarioxantecedenteFacadeREST");
//        Usuarioxantecedente expResult = null;
//        Usuarioxantecedente result = instance.find(id);
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of findAll method, of class UsuarioxantecedenteFacadeREST.
//     */
//    @Test
//    public void testFindAll() throws Exception {
//        System.out.println("findAll");
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        UsuarioxantecedenteFacadeREST instance = (UsuarioxantecedenteFacadeREST)container.getContext().lookup("java:global/classes/UsuarioxantecedenteFacadeREST");
//        List<Usuarioxantecedente> expResult = null;
//        List<Usuarioxantecedente> result = instance.findAll();
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of findRange method, of class UsuarioxantecedenteFacadeREST.
//     */
//    @Test
//    public void testFindRange_Integer_Integer() throws Exception {
//        System.out.println("findRange");
//        Integer from = null;
//        Integer to = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        UsuarioxantecedenteFacadeREST instance = (UsuarioxantecedenteFacadeREST)container.getContext().lookup("java:global/classes/UsuarioxantecedenteFacadeREST");
//        List<Usuarioxantecedente> expResult = null;
//        List<Usuarioxantecedente> result = instance.findRange(from, to);
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of countREST method, of class UsuarioxantecedenteFacadeREST.
//     */
//    @Test
//    public void testCountREST() throws Exception {
//        System.out.println("countREST");
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        UsuarioxantecedenteFacadeREST instance = (UsuarioxantecedenteFacadeREST)container.getContext().lookup("java:global/classes/UsuarioxantecedenteFacadeREST");
//        String expResult = "";
//        String result = instance.countREST();
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
    
}
