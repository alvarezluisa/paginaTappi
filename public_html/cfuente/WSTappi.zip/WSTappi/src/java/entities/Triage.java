/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author alvar
 */
@Entity
@Table(name = "TRIAGE", schema="APP")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Triage.findAll", query = "SELECT t FROM Triage t"),
    @NamedQuery(name = "Triage.findByIdtriage", query = "SELECT t FROM Triage t WHERE t.idtriage = :idtriage"),
    @NamedQuery(name = "Triage.findByNiveltriage", query = "SELECT t FROM Triage t WHERE t.niveltriage = :niveltriage"),
    @NamedQuery(name = "Triage.findByDx", query = "SELECT t FROM Triage t WHERE t.dx = :dx")})
public class Triage implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "IDTRIAGE")
    private Integer idtriage;
    @Column(name = "NIVELTRIAGE")
    private Integer niveltriage;
    @Size(max = 50)
    @Column(name = "DX")
    private String dx;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "triage")
    private List<Nivelurgencia> nivelurgenciaList;

    public Triage() {
    }

    public Triage(Integer idtriage) {
        this.idtriage = idtriage;
    }

    public Integer getIdtriage() {
        return idtriage;
    }

    public void setIdtriage(Integer idtriage) {
        this.idtriage = idtriage;
    }

    public Integer getNiveltriage() {
        return niveltriage;
    }

    public void setNiveltriage(Integer niveltriage) {
        this.niveltriage = niveltriage;
    }

    public String getDx() {
        return dx;
    }

    public void setDx(String dx) {
        this.dx = dx;
    }

    @XmlTransient
    public List<Nivelurgencia> getNivelurgenciaList() {
        return nivelurgenciaList;
    }

    public void setNivelurgenciaList(List<Nivelurgencia> nivelurgenciaList) {
        this.nivelurgenciaList = nivelurgenciaList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idtriage != null ? idtriage.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Triage)) {
            return false;
        }
        Triage other = (Triage) object;
        if ((this.idtriage == null && other.idtriage != null) || (this.idtriage != null && !this.idtriage.equals(other.idtriage))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Triage[ idtriage=" + idtriage + " ]";
    }
    
}
