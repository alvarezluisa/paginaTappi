/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entities.Historiaclinica;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import proxyRest.calcularTriageRestClient;

/**
 *
 * @author alvar
 */
public class CalcularTriageFacadeRESTTest {
    
    public CalcularTriageFacadeRESTTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of calculateTriage method, of class CalcularTriageFacadeREST.
     */
    @Test
    public void testCalculateTriage() {
        System.out.println("calculateTriage, Numero historia: ");
        // poner numero historia clinica
        Integer idhistoriaclinica = 6;
        Integer nivelTriage = 0;
        calcularTriageRestClient instance = new calcularTriageRestClient();
        Historiaclinica result = instance.calculateTriage_XML(Historiaclinica.class,idhistoriaclinica);
        assertEquals(nivelTriage, result.getNiveltriage());
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.")  
    }

    /**
     * Test of putXml method, of class CalcularTriageFacadeREST.
     */
//    @Test
//    public void testPutXml() {
//        System.out.println("putXml");
//        Historiaclinica content = null;  
//        CalcularTriageFacadeREST instance = new CalcularTriageFacadeREST();
//        instance.putXml(content);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }

    /**
     * Test of getEntityManager method, of class CalcularTriageFacadeREST.
     */
//    @Test
//    public void testGetEntityManager() {
//        System.out.println("getEntityManager");
//        CalcularTriageFacadeREST instance = new CalcularTriageFacadeREST();
//        EntityManager expResult = null;
//        EntityManager result = instance.getEntityManager();
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
    
}
