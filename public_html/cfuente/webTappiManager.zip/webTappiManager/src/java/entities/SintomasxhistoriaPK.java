/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author alvar
 */
@Embeddable
public class SintomasxhistoriaPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "HISTORIACLINICA_IDHC")
    private int historiaclinicaIdhc;
    @Basic(optional = false)
    @NotNull
    @Column(name = "SINTOMA_IDSINTOMA")
    private int sintomaIdsintoma;

    public SintomasxhistoriaPK() {
    }

    public SintomasxhistoriaPK(int historiaclinicaIdhc, int sintomaIdsintoma) {
        this.historiaclinicaIdhc = historiaclinicaIdhc;
        this.sintomaIdsintoma = sintomaIdsintoma;
    }

    public int getHistoriaclinicaIdhc() {
        return historiaclinicaIdhc;
    }

    public void setHistoriaclinicaIdhc(int historiaclinicaIdhc) {
        this.historiaclinicaIdhc = historiaclinicaIdhc;
    }

    public int getSintomaIdsintoma() {
        return sintomaIdsintoma;
    }

    public void setSintomaIdsintoma(int sintomaIdsintoma) {
        this.sintomaIdsintoma = sintomaIdsintoma;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) historiaclinicaIdhc;
        hash += (int) sintomaIdsintoma;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SintomasxhistoriaPK)) {
            return false;
        }
        SintomasxhistoriaPK other = (SintomasxhistoriaPK) object;
        if (this.historiaclinicaIdhc != other.historiaclinicaIdhc) {
            return false;
        }
        if (this.sintomaIdsintoma != other.sintomaIdsintoma) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.SintomasxhistoriaPK[ historiaclinicaIdhc=" + historiaclinicaIdhc + ", sintomaIdsintoma=" + sintomaIdsintoma + " ]";
    }
    
}
