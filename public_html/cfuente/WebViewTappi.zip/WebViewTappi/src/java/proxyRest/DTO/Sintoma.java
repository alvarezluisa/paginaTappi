/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proxyRest.DTO;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author alvar
 */
@Entity
@Table(name = "SINTOMA", schema="APP")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Sintoma.findAll", query = "SELECT s FROM Sintoma s"),
    @NamedQuery(name = "Sintoma.findByIdsintoma", query = "SELECT s FROM Sintoma s WHERE s.idsintoma = :idsintoma"),
    @NamedQuery(name = "Sintoma.findByDescripcionm", query = "SELECT s FROM Sintoma s WHERE s.descripcionm = :descripcionm"),
    @NamedQuery(name = "Sintoma.findByDescripcionp", query = "SELECT s FROM Sintoma s WHERE s.descripcionp = :descripcionp"),
    @NamedQuery(name = "Sintoma.findByCoordenadax", query = "SELECT s FROM Sintoma s WHERE s.coordenadax = :coordenadax"),
    @NamedQuery(name = "Sintoma.findByCoordenaday", query = "SELECT s FROM Sintoma s WHERE s.coordenaday = :coordenaday")})
public class Sintoma implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "IDSINTOMA")
    private Integer idsintoma;
    @Size(max = 100)
    @Column(name = "DESCRIPCIONM")
    private String descripcionm;
    @Size(max = 100)
    @Column(name = "DESCRIPCIONP")
    private String descripcionp;
    @Column(name = "COORDENADAX")
    private Integer coordenadax;
    @Column(name = "COORDENADAY")
    private Integer coordenaday;

    public Sintoma() {
    }

    public Sintoma(Integer idsintoma) {
        this.idsintoma = idsintoma;
    }

    public Integer getIdsintoma() {
        return idsintoma;
    }

    public void setIdsintoma(Integer idsintoma) {
        this.idsintoma = idsintoma;
    }

    public String getDescripcionm() {
        return descripcionm;
    }

    public void setDescripcionm(String descripcionm) {
        this.descripcionm = descripcionm;
    }

    public String getDescripcionp() {
        return descripcionp;
    }

    public void setDescripcionp(String descripcionp) {
        this.descripcionp = descripcionp;
    }

    public Integer getCoordenadax() {
        return coordenadax;
    }

    public void setCoordenadax(Integer coordenadax) {
        this.coordenadax = coordenadax;
    }

    public Integer getCoordenaday() {
        return coordenaday;
    }

    public void setCoordenaday(Integer coordenaday) {
        this.coordenaday = coordenaday;
    }


    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idsintoma != null ? idsintoma.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Sintoma)) {
            return false;
        }
        Sintoma other = (Sintoma) object;
        if ((this.idsintoma == null && other.idsintoma != null) || (this.idsintoma != null && !this.idsintoma.equals(other.idsintoma))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Sintoma[ idsintoma=" + idsintoma + " ]";
    }
    
}
