/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entities.Historiaclinica;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author alvar
 */
@Path("calculartriage")
public class CalcularTriageFacadeREST extends AbstractFacade<Historiaclinica> {

    @PersistenceContext(unitName = "WSTappiPU")
    private EntityManager em;

    /**
     * Creates a new instance of CalcularTriageFacadeREST
     */
    public CalcularTriageFacadeREST() {
        super(Historiaclinica.class);
    }

    /**
     * Retrieves representation of an instance of
     * service.CalcularTriageFacadeREST
     *
     * @param idhistoriaclinica
     * @return an instance of entities.Historiaclinica
     */
    @GET
    @Path("{idHC}")
    @Transactional
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Historiaclinica calculateTriage(@PathParam("idHC") Integer idhistoriaclinica) {

        Query query = em.createNativeQuery("select T.NIVELTRIAGE\n"
                + "from APP.Matching_Triage_with_clinic_history_by_number_of_symptoms mts, APP.Matching_Triage_with_clinic_history_by_presence mtp, APP.TRIAGE T\n"
                + "where mts.IDHISTORY = mtp.IDHISTORY \n"
                + "and mts.IDTRIAGE = mtp.IDTRIAGE\n"
                + "and mts.NUMBER_OF_SYMPTOMS = mtp.SYMPTOMS_MATCHING_BY_PRESENCE\n"
                + "and mts.IDTRIAGE = T.IDTRIAGE\n"
                + "and mts.IDHISTORY = ?");

        query.setParameter(1, idhistoriaclinica);

        Integer idt = null;
        Historiaclinica hc = null;
        try {
            hc = em.find(Historiaclinica.class, idhistoriaclinica);
        } catch (Exception ex1) {
            return null;

        }

        try {
            idt = (Integer) query.getSingleResult();
            //System.out.println("idt:" + idt);
            hc.setNiveltriage(idt);

        } catch (Exception ex) {
            hc.setNiveltriage(0);

        }
        try {
            super.edit(hc);
            em.flush();
            hc = em.find(Historiaclinica.class, idhistoriaclinica);
        } catch (Exception ex) {
            return null;
        }

        return hc;
    }

    /**
     * PUT method for updating or creating an instance of
     * CalcularTriageFacadeREST
     *
     * @param content representation for the resource
     */
    @PUT
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void putXml(Historiaclinica content) {
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
}
