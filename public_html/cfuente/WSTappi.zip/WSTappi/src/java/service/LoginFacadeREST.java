/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entities.Usuario;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 * En el path se pone la palabra login para ingresar a los servicios de esta clase
 * @author alvar
 */
@Path("login")
public class LoginFacadeREST {

    @PersistenceContext(unitName = "WSTappiPU")
    private EntityManager em;
    /**
     * Creates a new instance of LoginResource
     */
    public LoginFacadeREST() {
    }
    
    
    
    

    /**
     * Retrieves representation of an instance of service.LoginFacadeREST
     * @param login
     * @return an instance of java.lang.String
     */
//    @GET
//    @Produces(MediaType.APPLICATION_XML)
//    public String getXml() {
//        //TODO return proper representation object
//        throw new UnsupportedOperationException();
//    }
    @GET
    @Path("{idFG}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Usuario findByLogin(@PathParam("idFG") String fg) {
        /* Se escribe el id de facebook o de google al inciar sesion, este lleva a cabo una busqueda 
        en las tablas de la aplicacion y devuelve el usuario el cual tiene ese id, con el fin de que 
        se tenga la informacion de a quien le corresponde la cuenta.
        Si el id de facebook no existe retorna null
        */
        
               
        List<Usuario> users = em.createNamedQuery("Usuario.findByIdfacegoo")
                .setParameter("idfacegoo", fg).getResultList();
        if(users.size()>0){
            return users.get(0);
        }
        else{
            return null;
        }
    }
    /**
     * PUT method for updating or creating an instance of LoginFacadeREST
     * @param content representation for the resource
     */
    @PUT
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void putXml(String content) {
    }
}
