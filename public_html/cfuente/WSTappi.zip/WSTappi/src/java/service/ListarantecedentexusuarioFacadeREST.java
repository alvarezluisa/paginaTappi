/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entities.Antecedente;
import entities.Usuarioxantecedente;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author alvar
 */
@Path("Listarantecedentexusuario")
public class ListarantecedentexusuarioFacadeREST {

    @PersistenceContext(unitName = "WSTappiPU")
    private EntityManager em;
    /**
     * Creates a new instance of ListarantecedentexusuarioFacadeREST
     */
    public ListarantecedentexusuarioFacadeREST() {
    }

    /**
     * Retrieves representation of an instance of service.ListarantecedentexusuarioFacadeREST
     * @param idus
     * @return an instance of entities.Antecedentexusuario
     */
    @GET
    @Path("{idU}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List <Usuarioxantecedente> findByantedentesbyusuario(@PathParam("idU") Integer idus) {
        List<Usuarioxantecedente> s = 
                em.createNamedQuery("Usuarioxantecedente.findByUsuarioIdusuario")
                        .setParameter("usuarioIdusuario", idus)
                        .getResultList();
        return s;
       
    }
    /**
     * PUT method for updating or creating an instance of ListarantecedentexusuarioFacadeREST
     * @param content representation for the resource
     */
    @PUT
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void putXml(Antecedente content) {
    }
}
