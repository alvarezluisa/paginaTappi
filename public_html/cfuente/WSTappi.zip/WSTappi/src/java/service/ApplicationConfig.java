/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import java.util.Set;
import javax.ws.rs.core.Application;

/**
 *
 * @author alvar
 */
@javax.ws.rs.ApplicationPath("webresources")
public class ApplicationConfig extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new java.util.HashSet<>();
        addRestResourceClasses(resources);
        return resources;
    }

    /**
     * Do not modify addRestResourceClasses() method.
     * It is automatically populated with
     * all resources defined in the project.
     * If required, comment out calling this method in getClasses().
     */
    private void addRestResourceClasses(Set<Class<?>> resources) {
        resources.add(service.AntecedenteFacadeREST.class);
        resources.add(service.AntecedentexTipoFacadeREST.class);
        resources.add(service.CalcularTriageFacadeREST.class);
        resources.add(service.HistoriaclinicaFacadeREST.class);
        resources.add(service.LineasemergenciaFacadeREST.class);
        resources.add(service.ListaHistoriaClinicaXUsuarioFacadeREST.class);
        resources.add(service.ListarantecedentexusuarioFacadeREST.class);
        resources.add(service.ListasintomasxhistoriaclinicaFacadeREST.class);
        resources.add(service.LoginFacadeREST.class);
        resources.add(service.NivelurgenciaFacadeREST.class);
        resources.add(service.SintomaFacadeREST.class);
        resources.add(service.SintomasxhistoriaFacadeREST.class);
        resources.add(service.TriageFacadeREST.class);
        resources.add(service.UsuarioFacadeREST.class);
        resources.add(service.UsuarioxantecedenteFacadeREST.class);
    }
    
}
