/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entities.Usuario;
import java.sql.Date;
import javax.ejb.embeddable.EJBContainer;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author alvar
 */
public class UsuarioFacadeRESTTest {
    
    public UsuarioFacadeRESTTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of edit method, of class UsuarioFacadeREST.
     */
//    @Test
//    public void testEdit_GenericType() throws Exception {
//        System.out.println("edit");
//        Usuario entity = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        UsuarioFacadeREST instance = (UsuarioFacadeREST)container.getContext().lookup("java:global/classes/UsuarioFacadeREST");
//        instance.edit(entity);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }

    /**
     * Test of remove method, of class UsuarioFacadeREST.
     */
//    @Test
//    public void testRemove_GenericType() throws Exception {
//        System.out.println("remove");
//        Usuario entity = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//       
//        UsuarioFacadeREST instance = 
//                (UsuarioFacadeREST)
//                container.getContext().lookup("java:global/classes/UsuarioFacadeREST");
//        entity= instance.find(3);
//        instance.remove(entity);
//        Usuario find = null;
//        try{
//            instance.find(3);
//        }catch(Exception ex){
//            //
//        }
//        assertNull(find);
//        container.close();
//        
//        // TODO review the generated test code and remove the default call to fail.
//        //fail("The test case is a prototype.");
//    }

    /**
     * Test of find method, of class UsuarioFacadeREST.
     */
    @Test
    public void testFind_Object() throws Exception {
        System.out.println("find");
        Integer id = 3;
        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
        UsuarioFacadeREST instance = (UsuarioFacadeREST)container.getContext().lookup("java:global/classes/UsuarioFacadeREST");
        Usuario expResult = null;
        Usuario result = instance.find(id);
        assertEquals(expResult, result);
        container.close();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of findRange method, of class UsuarioFacadeREST.
     */
//    @Test
//    public void testFindRange_intArr() throws Exception {
//        System.out.println("findRange");
//        int[] range = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        UsuarioFacadeREST instance = (UsuarioFacadeREST)container.getContext().lookup("java:global/classes/UsuarioFacadeREST");
//        List<Usuario> expResult = null;
//        List<Usuario> result = instance.findRange(range);
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }

    /**
     * Test of count method, of class UsuarioFacadeREST.
     */
//    @Test
//    public void testCount() throws Exception {
//        System.out.println("count");
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        UsuarioFacadeREST instance = (UsuarioFacadeREST)container.getContext().lookup("java:global/classes/UsuarioFacadeREST");
//        int expResult = 0;
//        int result = instance.count();
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }

    /**
     * Test of create method, of class UsuarioFacadeREST.
     */
//    @Test
//    public void testCreate() throws Exception {
//        System.out.println("create");
//        Usuario entity = new Usuario ();
//        entity.setIdusuario(3);
//        entity.setIdfacegoo("123");
//        entity.setCedula(755555757);
//        entity.setCorreo("VALENCIA.@GMAIL.COM");
//        entity.setDireccion("CR 40 #9");
//        entity.setFechanacimiento(new Date(1998,10,11));
//        entity.setGenero('M');
//        entity.setNombre("FERNAN");
//        entity.setRol("P");
//        entity.setTiposangre("AB+");
//        entity.setEps("CAFESALUD");
//        entity.setAbortos(0);
//        entity.setCesareas(0);
//        entity.setFechaprimerperiodo(new Date(0001,10,11));
//        entity.setFechaultimoperiodo(new Date (0001,01,18));
//        entity.setMetodoanticonceptivo("");
//        entity.setGestas(0);
//        entity.setPartos(0);
//        
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        UsuarioFacadeREST instance = (UsuarioFacadeREST)
//                container.getContext().lookup("java:global/classes/UsuarioFacadeREST");
//        instance.create(entity);
//        container.close();
//        assertEquals(new Integer (3), entity.getIdusuario());
//        // TODO review the generated test code and remove the default call to fail.
//        //fail("The test case is a prototype.");
//    }

    /**
     * Test of edit method, of class UsuarioFacadeREST.
     * Se debe probar el método de PUT para la clase Usuario en el servidor.
     */
//    @Test
//    public void testEdit_Integer_Usuario() throws Exception {
//        System.out.println("edit");
//        Integer id = 1;
//        Usuario entity = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        UsuarioFacadeREST instance = 
//                (UsuarioFacadeREST)container.getContext().lookup("java:global/classes/UsuarioFacadeREST");
//        entity = instance.find(id);
//        String expResult = "Lorenza";
//        entity.setNombre(expResult);
//        instance.edit(id, entity);
//        entity = instance.find(id);
//        assertEquals(expResult, entity.getNombre());
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        //fail("The test case is a prototype.");
//    }

    /**
     * Test of remove method, of class UsuarioFacadeREST.
     */
//    @Test
//    public void testRemove_Integer() throws Exception {
//        System.out.println("remove");
//        Integer id = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        UsuarioFacadeREST instance = (UsuarioFacadeREST)container.getContext().lookup("java:global/classes/UsuarioFacadeREST");
//        instance.remove(id);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }

    /**
     * Test of find method, of class UsuarioFacadeREST.
     */
//    @Test
//    public void testFind_Integer() throws Exception {
//        System.out.println("find");
//        Integer id = 1;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        UsuarioFacadeREST instance = (UsuarioFacadeREST)container.getContext().lookup("java:global/classes/UsuarioFacadeREST");
//        String expResult = "123";
//        Usuario result = instance.find(id);
//        assertEquals(expResult, result.getIdfacegoo());
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        //fail("The test case is a prototype.");
//    }

    /**
     * Test of findAll method, of class UsuarioFacadeREST.
     */
//    @Test
//    public void testFindAll() throws Exception {
//        System.out.println("findAll");
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        UsuarioFacadeREST instance = (UsuarioFacadeREST)container.getContext().lookup("java:global/classes/UsuarioFacadeREST");
//        List<Usuario> expResult = null;
//        List<Usuario> result = instance.findAll();
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }

    /**
     * Test of findRange method, of class UsuarioFacadeREST.
     */
//    @Test
//    public void testFindRange_Integer_Integer() throws Exception {
//        System.out.println("findRange");
//        Integer from = null;
//        Integer to = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        UsuarioFacadeREST instance = (UsuarioFacadeREST)container.getContext().lookup("java:global/classes/UsuarioFacadeREST");
//        List<Usuario> expResult = null;
//        List<Usuario> result = instance.findRange(from, to);
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }

    /**
     * Test of countREST method, of class UsuarioFacadeREST.
     */
//    @Test
//    public void testCountREST() throws Exception {
//        System.out.println("countREST");
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        UsuarioFacadeREST instance = (UsuarioFacadeREST)container.getContext().lookup("java:global/classes/UsuarioFacadeREST");
//        String expResult = "";
//        String result = instance.countREST();
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
    
}
