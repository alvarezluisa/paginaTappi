/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entities.Sintoma;
import entities.Sintomasxhistoria;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author alvar
 */
@Path("listasintomasxhistoriaclinica")
public class ListasintomasxhistoriaclinicaFacadeREST {

    @PersistenceContext(unitName = "WSTappiPU")
    private EntityManager em;

    /**
     * Creates a new instance of ListasintomasxhistoriaclinicaFacadeREST
     */
    public ListasintomasxhistoriaclinicaFacadeREST() {
    }

    /**
     * Retrieves representation of an instance of service.ListasintomasxhistoriaclinicaFacadeREST
     * @param idhistoria
     * @return an instance of entities.Sintoma
     */
    
    @GET
    @Path("{idHC}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List <Sintomasxhistoria> findBysintomaxhistoriaclinica(@PathParam("idHC") Integer idhistoria) {
        
        List<Sintomasxhistoria> s = 
                em.createNamedQuery("Sintomasxhistoria.findByHistoriaclinicaIdhc")
                        .setParameter("historiaclinicaIdhc", idhistoria)
                        .getResultList();
//        List<Sintoma> sint= new ArrayList<Sintoma>();
//        
//        for (Sintomasxhistoria si:s) {
//            if(idhistoria==si.getSintomasxhistoriaPK().getHistoriaclinicaIdhc())
//                sint.add(si.getSintoma());
//            
//        }
//        System.out.println("id : "+ idhistoria+ "tam"+ sint.size());
        return s;

//             List<Sintoma> s = 
//                em.createNamedQuery("Sintomasxhistoria.findByHistoriaclinicaIdhcSintomas")
//                        .setParameter("historiaclinicaIdhc", idhistoria)
//                        .getResultList();
//             return s;
       
    }
    
    /**
     * PUT method for updating or creating an instance of ListasintomasxhistoriaclinicaFacadeREST
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_XML)
    public void putXml(Sintoma content) {
    }
}
