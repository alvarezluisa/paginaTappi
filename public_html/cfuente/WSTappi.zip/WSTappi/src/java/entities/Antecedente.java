/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author alvar
 */
@Entity
@Table(name = "ANTECEDENTE", schema="APP")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Antecedente.findAll", query = "SELECT a FROM Antecedente a"),
    @NamedQuery(name = "Antecedente.findByIdantecedente", query = "SELECT a FROM Antecedente a WHERE a.idantecedente = :idantecedente"),
    @NamedQuery(name = "Antecedente.findByDescripcion", query = "SELECT a FROM Antecedente a WHERE a.descripcion = :descripcion"),
    @NamedQuery(name = "Antecedente.findByTipo", query = "SELECT a FROM Antecedente a WHERE a.tipo = :tipo")})
public class Antecedente implements Serializable {

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "antecedente")
    private List<Usuarioxantecedente> usuarioxantecedenteList;

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "IDANTECEDENTE")
    private Integer idantecedente;
    @Size(max = 100)
    @Column(name = "DESCRIPCION")
    private String descripcion;
    @Size(max = 50)
    @Column(name = "TIPO")
    private String tipo;
    @JoinTable(name = "USUARIOXANTECEDENTE", joinColumns = {
        @JoinColumn(name = "ANTECEDENTE_IDANTECEDENTE", referencedColumnName = "IDANTECEDENTE")}, inverseJoinColumns = {
        @JoinColumn(name = "USUARIO_IDUSUARIO", referencedColumnName = "IDUSUARIO")}, schema="APP")
    @ManyToMany
    private List<Usuario> usuarioList;

    public Antecedente() {
    }

    public Antecedente(Integer idantecedente) {
        this.idantecedente = idantecedente;
    }

    public Integer getIdantecedente() {
        return idantecedente;
    }

    public void setIdantecedente(Integer idantecedente) {
        this.idantecedente = idantecedente;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @XmlTransient
    public List<Usuario> getUsuarioList() {
        return usuarioList;
    }

    public void setUsuarioList(List<Usuario> usuarioList) {
        this.usuarioList = usuarioList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idantecedente != null ? idantecedente.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Antecedente)) {
            return false;
        }
        Antecedente other = (Antecedente) object;
        if ((this.idantecedente == null && other.idantecedente != null) || (this.idantecedente != null && !this.idantecedente.equals(other.idantecedente))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Antecedente[ idantecedente=" + idantecedente + " ]";
    }

    @XmlTransient
    public List<Usuarioxantecedente> getUsuarioxantecedenteList() {
        return usuarioxantecedenteList;
    }

    public void setUsuarioxantecedenteList(List<Usuarioxantecedente> usuarioxantecedenteList) {
        this.usuarioxantecedenteList = usuarioxantecedenteList;
    }
    
}
