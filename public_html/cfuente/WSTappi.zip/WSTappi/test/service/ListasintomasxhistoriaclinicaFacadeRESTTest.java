/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entities.Sintoma;
import entities.Sintomasxhistoria;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author alvar
 */
public class ListasintomasxhistoriaclinicaFacadeRESTTest {
    
    public ListasintomasxhistoriaclinicaFacadeRESTTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of findBysintomaxhistoriaclinica method, of class ListasintomasxhistoriaclinicaFacadeREST.
     */
    @Test
    public void testFindBysintomaxhistoriaclinica() {
        System.out.println("findBysintomaxhistoriaclinica");
        Integer idhistoria = null;
        ListasintomasxhistoriaclinicaFacadeREST instance = new ListasintomasxhistoriaclinicaFacadeREST();
        List<Sintomasxhistoria> expResult = null;
        List<Sintomasxhistoria> result = instance.findBysintomaxhistoriaclinica(idhistoria);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of putXml method, of class ListasintomasxhistoriaclinicaFacadeREST.
     */
    @Test
    public void testPutXml() {
        System.out.println("putXml");
        Sintoma content = null;
        ListasintomasxhistoriaclinicaFacadeREST instance = new ListasintomasxhistoriaclinicaFacadeREST();
        instance.putXml(content);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
