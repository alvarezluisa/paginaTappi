/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author alvar
 */
@Embeddable
public class NivelurgenciaPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "SINTOMA_IDSINTOMA")
    private int sintomaIdsintoma;
    @Basic(optional = false)
    @NotNull
    @Column(name = "TRIAGE_IDTRIAGE")
    private int triageIdtriage;

    public NivelurgenciaPK() {
    }

    public NivelurgenciaPK(int sintomaIdsintoma, int triageIdtriage) {
        this.sintomaIdsintoma = sintomaIdsintoma;
        this.triageIdtriage = triageIdtriage;
    }

    public int getSintomaIdsintoma() {
        return sintomaIdsintoma;
    }

    public void setSintomaIdsintoma(int sintomaIdsintoma) {
        this.sintomaIdsintoma = sintomaIdsintoma;
    }

    public int getTriageIdtriage() {
        return triageIdtriage;
    }

    public void setTriageIdtriage(int triageIdtriage) {
        this.triageIdtriage = triageIdtriage;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) sintomaIdsintoma;
        hash += (int) triageIdtriage;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof NivelurgenciaPK)) {
            return false;
        }
        NivelurgenciaPK other = (NivelurgenciaPK) object;
        if (this.sintomaIdsintoma != other.sintomaIdsintoma) {
            return false;
        }
        if (this.triageIdtriage != other.triageIdtriage) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.NivelurgenciaPK[ sintomaIdsintoma=" + sintomaIdsintoma + ", triageIdtriage=" + triageIdtriage + " ]";
    }
    
}
