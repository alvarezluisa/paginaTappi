/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author alvar
 */
@Entity
@Table(name = "NIVELURGENCIA", schema="APP")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Nivelurgencia.findAll", query = "SELECT n FROM Nivelurgencia n"),
    @NamedQuery(name = "Nivelurgencia.findBySintomaIdsintoma", query = "SELECT n FROM Nivelurgencia n WHERE n.nivelurgenciaPK.sintomaIdsintoma = :sintomaIdsintoma"),
    @NamedQuery(name = "Nivelurgencia.findByTriageIdtriage", query = "SELECT n FROM Nivelurgencia n WHERE n.nivelurgenciaPK.triageIdtriage = :triageIdtriage"),
    @NamedQuery(name = "Nivelurgencia.findByPresencia", query = "SELECT n FROM Nivelurgencia n WHERE n.presencia = :presencia")})
public class Nivelurgencia implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected NivelurgenciaPK nivelurgenciaPK;
    @Size(max = 2)
    @Column(name = "PRESENCIA")
    private String presencia;
    @JoinColumn(name = "SINTOMA_IDSINTOMA", referencedColumnName = "IDSINTOMA", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Sintoma sintoma;
    @JoinColumn(name = "TRIAGE_IDTRIAGE", referencedColumnName = "IDTRIAGE", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Triage triage;

    public Nivelurgencia() {
    }

    public Nivelurgencia(NivelurgenciaPK nivelurgenciaPK) {
        this.nivelurgenciaPK = nivelurgenciaPK;
    }

    public Nivelurgencia(int sintomaIdsintoma, int triageIdtriage) {
        this.nivelurgenciaPK = new NivelurgenciaPK(sintomaIdsintoma, triageIdtriage);
    }

    public NivelurgenciaPK getNivelurgenciaPK() {
        return nivelurgenciaPK;
    }

    public void setNivelurgenciaPK(NivelurgenciaPK nivelurgenciaPK) {
        this.nivelurgenciaPK = nivelurgenciaPK;
    }

    public String getPresencia() {
        return presencia;
    }

    public void setPresencia(String presencia) {
        this.presencia = presencia;
    }

    public Sintoma getSintoma() {
        return sintoma;
    }

    public void setSintoma(Sintoma sintoma) {
        this.sintoma = sintoma;
    }

    public Triage getTriage() {
        return triage;
    }

    public void setTriage(Triage triage) {
        this.triage = triage;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (nivelurgenciaPK != null ? nivelurgenciaPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Nivelurgencia)) {
            return false;
        }
        Nivelurgencia other = (Nivelurgencia) object;
        if ((this.nivelurgenciaPK == null && other.nivelurgenciaPK != null) || (this.nivelurgenciaPK != null && !this.nivelurgenciaPK.equals(other.nivelurgenciaPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Nivelurgencia[ nivelurgenciaPK=" + nivelurgenciaPK + " ]";
    }
    
}
