/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entities.Antecedente;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author alvar
 */
@Stateless
@Path("AntecedentexTipo")
public class AntecedentexTipoFacadeREST {

    @PersistenceContext(unitName = "WSTappiPU")
    private EntityManager em;

    /**
     * Creates a new instance of AntecedentexTipoFacadeREST
     */
    public AntecedentexTipoFacadeREST() {
    }


    /**
     * PUT method for updating or creating an instance of AntecedentexTipoFacadeREST
     * @param content representation for the resource
     */
    @PUT
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void putXml(String content) {
    }
    
    @GET
    @Path("{type}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List <Antecedente> findByType(@PathParam("type") String t) {
        
        List <Antecedente> a = 
                em.createNamedQuery("Antecedente.findByTipo")
                        .setParameter("tipo", t)
                        .getResultList();
        
        return a;
       
    }
}
