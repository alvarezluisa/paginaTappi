/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entities.Sintoma;
import java.util.List;
import javax.ejb.embeddable.EJBContainer;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author alvar
 */
public class SintomaFacadeRESTTest {
    
    public SintomaFacadeRESTTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of edit method, of class SintomaFacadeREST.
     */
//    @Test
//    public void testEdit_GenericType() throws Exception {
//        System.out.println("edit");
//        Sintoma entity = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        SintomaFacadeREST instance = (SintomaFacadeREST)container.getContext().lookup("java:global/classes/SintomaFacadeREST");
//        instance.edit(entity);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }

    /**
     * Test of remove method, of class SintomaFacadeREST.
     */
//    @Test
//    public void testRemove_GenericType() throws Exception {
//        System.out.println("remove");
//        Sintoma entity = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        SintomaFacadeREST instance = (SintomaFacadeREST)container.getContext().lookup("java:global/classes/SintomaFacadeREST");
//        instance.remove(entity);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }

    /**
     * Test of find method, of class SintomaFacadeREST.
     */
//    @Test
//    public void testFind_Object() throws Exception {
//        System.out.println("find");
//        Object id = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        SintomaFacadeREST instance = (SintomaFacadeREST)container.getContext().lookup("java:global/classes/SintomaFacadeREST");
//        Sintoma expResult = null;
//        Sintoma result = instance.find(id);
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of findRange method, of class SintomaFacadeREST.
//     */
//    @Test
//    public void testFindRange_intArr() throws Exception {
//        System.out.println("findRange");
//        int[] range = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        SintomaFacadeREST instance = (SintomaFacadeREST)container.getContext().lookup("java:global/classes/SintomaFacadeREST");
//        List<Sintoma> expResult = null;
//        List<Sintoma> result = instance.findRange(range);
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of count method, of class SintomaFacadeREST.
//     */
//    @Test
//    public void testCount() throws Exception {
//        System.out.println("count");
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        SintomaFacadeREST instance = (SintomaFacadeREST)container.getContext().lookup("java:global/classes/SintomaFacadeREST");
//        int expResult = 0;
//        int result = instance.count();
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of create method, of class SintomaFacadeREST.
//     */
//    @Test
//    public void testCreate() throws Exception {
//        System.out.println("create");
//        Sintoma entity;
//        entity = new Sintoma();
//        entity.setCoordenadax(1);
//        entity.setCoordenaday(1);
//        entity.setDescripcionp("hola");
//        entity.setDescripcionm("Hola");
//        //entity.setIdsintoma("bla");
//       
//        
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        SintomaFacadeREST instance = (SintomaFacadeREST)container.getContext().lookup("java:global/classes/SintomaFacadeREST");
//        instance.create(entity);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of edit method, of class SintomaFacadeREST.
//     */
//    @Test
//    public void testEdit_Integer_Sintoma() throws Exception {
//        System.out.println("edit");
//        Integer id = null;
//        Sintoma entity = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        SintomaFacadeREST instance = (SintomaFacadeREST)container.getContext().lookup("java:global/classes/SintomaFacadeREST");
//        instance.edit(id, entity);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of remove method, of class SintomaFacadeREST.
//     */
//    @Test
//    public void testRemove_Integer() throws Exception {
//        System.out.println("remove");
//        Integer id = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        SintomaFacadeREST instance = (SintomaFacadeREST)container.getContext().lookup("java:global/classes/SintomaFacadeREST");
//        instance.remove(id);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of find method, of class SintomaFacadeREST.
//     */
//    @Test
//    public void testFind_Integer() throws Exception {
//        System.out.println("find");
//        Integer id = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        SintomaFacadeREST instance = (SintomaFacadeREST)container.getContext().lookup("java:global/classes/SintomaFacadeREST");
//        Sintoma expResult = null;
//        Sintoma result = instance.find(id);
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of findAll method, of class SintomaFacadeREST.
//     */
    @Test
    public void testFindAll() throws Exception {
        System.out.println("findAll");
        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
        SintomaFacadeREST instance = (SintomaFacadeREST)container.getContext().lookup("java:global/classes/SintomaFacadeREST");
        Integer expResult = 16;
        List<Sintoma> result = instance.findAll();
        assertEquals(expResult, new Integer(result.size()));
        container.close();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
//
//    /**
//     * Test of findRange method, of class SintomaFacadeREST.
//     */
//    @Test
//    public void testFindRange_Integer_Integer() throws Exception {
//        System.out.println("findRange");
//        Integer from = null;
//        Integer to = null;
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        SintomaFacadeREST instance = (SintomaFacadeREST)container.getContext().lookup("java:global/classes/SintomaFacadeREST");
//        List<Sintoma> expResult = null;
//        List<Sintoma> result = instance.findRange(from, to);
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of countREST method, of class SintomaFacadeREST.
//     */
//    @Test
//    public void testCountREST() throws Exception {
//        System.out.println("countREST");
//        EJBContainer container = javax.ejb.embeddable.EJBContainer.createEJBContainer();
//        SintomaFacadeREST instance = (SintomaFacadeREST)container.getContext().lookup("java:global/classes/SintomaFacadeREST");
//        String expResult = "";
//        String result = instance.countREST();
//        assertEquals(expResult, result);
//        container.close();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
    
}
