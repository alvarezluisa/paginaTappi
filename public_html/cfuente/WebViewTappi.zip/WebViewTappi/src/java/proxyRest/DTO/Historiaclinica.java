/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proxyRest.DTO;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author alvar
 */
@Entity
@Table(name = "HISTORIACLINICA", schema="APP")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Historiaclinica.findAll", query = "SELECT h FROM Historiaclinica h"),
    @NamedQuery(name = "Historiaclinica.findByIdhistoriaclinica", query = "SELECT h FROM Historiaclinica h WHERE h.idhistoriaclinica = :idhistoriaclinica"),
    @NamedQuery(name = "Historiaclinica.findByDescripcionmotivourgencia", query = "SELECT h FROM Historiaclinica h WHERE h.descripcionmotivourgencia = :descripcionmotivourgencia"),
    @NamedQuery(name = "Historiaclinica.findByIniciomotivourgencia", query = "SELECT h FROM Historiaclinica h WHERE h.iniciomotivourgencia = :iniciomotivourgencia"),
    @NamedQuery(name = "Historiaclinica.findByFecha", query = "SELECT h FROM Historiaclinica h WHERE h.fecha = :fecha"),
    @NamedQuery(name = "Historiaclinica.findHCByUser", 
                query = "SELECT h FROM Historiaclinica h WHERE h.usuarioIdusuario.idusuario = :idusuario")
               })
public class Historiaclinica implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "IDHISTORIACLINICA")
    private Integer idhistoriaclinica;
    @Size(max = 500)
    @Column(name = "DESCRIPCIONMOTIVOURGENCIA")
    private String descripcionmotivourgencia;
    @Column(name = "INICIOMOTIVOURGENCIA")
    @Temporal(TemporalType.DATE)
    private Date iniciomotivourgencia;
    @Column(name = "FECHA")
    @Temporal(TemporalType.DATE)
    private Date fecha;
    @JoinColumn(name = "USUARIO_IDUSUARIO", referencedColumnName = "IDUSUARIO")
    @ManyToOne(optional = false)
    private Usuario usuarioIdusuario;
//    @OneToMany(cascade = CascadeType.ALL, mappedBy = "historiaclinica")
//    private List<Sintomasxhistoria> sintomasxhistoriaList;
    @Column(name = "NIVELTRIAGE")
    private Integer niveltriage;

    public Historiaclinica() {
    }
    
    public Historiaclinica(Date fecha) {
        fecha = fecha;
        iniciomotivourgencia = fecha;
    }

    public Historiaclinica(Integer idhistoriaclinica) {
        this.idhistoriaclinica = idhistoriaclinica;
    }

    public Integer getIdhistoriaclinica() {
        return idhistoriaclinica;
    }

    public void setIdhistoriaclinica(Integer idhistoriaclinica) {
        this.idhistoriaclinica = idhistoriaclinica;
    }

    public String getDescripcionmotivourgencia() {
        return descripcionmotivourgencia;
    }

    public void setDescripcionmotivourgencia(String descripcionmotivourgencia) {
        this.descripcionmotivourgencia = descripcionmotivourgencia;
    }

    public Date getIniciomotivourgencia() {
        return iniciomotivourgencia;
    }

    public void setIniciomotivourgencia(Date iniciomotivourgencia) {
        this.iniciomotivourgencia = iniciomotivourgencia;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Usuario getUsuarioIdusuario() {
        return usuarioIdusuario;
    }

    public void setUsuarioIdusuario(Usuario usuarioIdusuario) {
        this.usuarioIdusuario = usuarioIdusuario;
    }
//
//    @XmlTransient
//    public List<Sintomasxhistoria> getSintomasxhistoriaList() {
//        return sintomasxhistoriaList;
//    }
//
//    public void setSintomasxhistoriaList(List<Sintomasxhistoria> sintomasxhistoriaList) {
//        this.sintomasxhistoriaList = sintomasxhistoriaList;
//    }
//
    public Integer getNiveltriage() {
        return niveltriage;
    }

    public void setNiveltriage(Integer niveltriage) {
        this.niveltriage = niveltriage;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idhistoriaclinica != null ? idhistoriaclinica.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Historiaclinica)) {
            return false;
        }
        Historiaclinica other = (Historiaclinica) object;
        if ((this.idhistoriaclinica == null && other.idhistoriaclinica != null) || (this.idhistoriaclinica != null && !this.idhistoriaclinica.equals(other.idhistoriaclinica))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Historiaclinica[ idhistoriaclinica=" + idhistoriaclinica + " ]";
    }
    
}
